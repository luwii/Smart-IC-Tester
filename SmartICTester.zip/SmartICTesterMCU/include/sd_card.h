#ifndef SD_CARD
#define SD_CARD

void SD_init();
void autoSearch(int pins);
void manualSearch(String number);

#endif SD_CARD

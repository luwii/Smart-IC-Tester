#include <Arduino.h>
/***********************************************************************************************************
 * luwii - Jan 2020
 * Merged all the ino files into one .cpp - ic_tester.cpp to solve scope issues
 * Added the Prototypes section
 * Moved the AdaFruit_GFX.h file from the source folder to one level up (as there is two)
 *   Not sure which is the correct one.
 * Removed all the FontConvert folders - contains source code of a utility. 
 *   Compiler wants to compile it with this.
 * Replaced screen library Adafruit_TFTLCD.h with MCUFRIEND_kbv.h
 * In tft_init() setrotation changed from 3 to 0
 * Fiddled with loop() String getIC() sections to fix touch sensor for screen rotation in the while loop
 * ***********************************************************************************************************/
#include <FastLED.h>

#define LED_PIN     46
#define NUM_LEDS    2
#define BRIGHTNESS  200
#define LED_TYPE    WS2812B

#define COLOR_ORDER GRB
CRGB leds[NUM_LEDS];

//TFT
#include <Adafruit_GFX.h>        // Core graphics library
//#include <Adafruit_TFTLCD.h>   // Hardware-specific library
#include <MCUFRIEND_kbv.h>       // Replaces Adafruit_TFTLCD.h

#include <TouchScreen.h> //Touch Screen Library

#define LCD_CS A3 // Chip Select goes to Analog 3
#define LCD_CD A2 // Command/Data goes to Analog 2
#define LCD_WR A1 // LCD Write goes to Analog 1
#define LCD_RD A0 // LCD Read goes to Analog 0
#define LCD_RESET A4 // LCD RESET goes to Analog 4

#define YP A1  // must be an analog pin, use "An" notation! A3
#define XM A2  // must be an analog pin, use "An" notation! A2
#define YM 7   // can be a digital pin 9
#define XP 6   // can be a digital pin 8

#define TS_MINX 285 //Was 150
#define TS_MINY 185 //Was 120
#define TS_MAXX 880 //Was 920
#define TS_MAXY 920 //Was 940

#define MINPRESSURE 10
#define MAXPRESSURE 1000

// Assign human-readable names to some common 16-bit color values:
#define BLACK   0x0000
#define BLUE    0x001F
#define RED     0xF800
#define GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF


//TFT initialization
// Adafruit_TFTLCD tft(LCD_CS, LCD_CD, LCD_WR, LCD_RD, LCD_RESET); // Replaced by line below
MCUFRIEND_kbv tft;        // Creates tft Object
TouchScreen ts = TouchScreen(XP, YP, XM, YM, 300);
Adafruit_GFX_Button buttons[12];

// Prototypes
void tft_init();
void SD_init();
void startScreen();
void modeScreen();
void autoScreen();
void autoSearch(int pinCount);
void manualScreen();
String getIC();
void manualSearch(String number);
boolean testCase(String test, int pins);
void testingIC(String s);   
void searching(int i); //in TFTLCD

//SD CARD
#include <SPI.h>
#include <SD.h>


#define chipSelect 10

//Pin Definitions
int pin14[14] = {30, 32, 34, 36, 38, 40, 42, 43, 41, 39, 37, 35, 33, 31};
int pin16[16] = {30, 32, 34, 36, 38, 40, 42, 44, 45, 43, 41, 39, 37, 35, 33, 31};

//Database File name
#define fname "database.txt"

//Structure Definiton for IC
typedef struct {
  String num;
  String name;
} IC;

//Function Headers
boolean testIC(String buffer, int pins);
void autoSearchResult(int mode, String number = "", String name = "", int count = 0);
void manualSearchResult(String number, String name, int status);

int screenStatus = 0, lastStatus = 0;
int *pin, pinCount = 0;

void(* resetFunc) (void) = 0;


void setup() {
  
  Serial.begin(9600);

  delay( 1000 ); // power-up safety delay
  FastLED.addLeds<LED_TYPE, LED_PIN, COLOR_ORDER>(leds, NUM_LEDS).setCorrection( TypicalLEDStrip );
  FastLED.setBrightness(  BRIGHTNESS );

  //TFT setup
  tft_init();

  //SD Card Setup
  SD_init();

}

void loop() {

  digitalWrite(13, HIGH);
  TSPoint p = ts.getPoint();
  digitalWrite(13, LOW);
  pinMode(XM, OUTPUT);
  pinMode(YP, OUTPUT);
  //Serial.println("Z: " + String(p.z) + " X: " + String(p.x) + " Y: " + String(p.y));
  if (p.z > MINPRESSURE && p.z < MAXPRESSURE)
  {
    //Serial.println("Original Z: " + String(p.z) + " X: " + String(p.x) + " Y: " + String(p.y));
   
    //Swapping for Set Rotation
    p.x = p.x + p.y;
    p.y = p.x - p.y;
    p.x = p.x - p.y; 
  
    //Serial.println("Swapped Z: " + String(p.z) + " X: " + String(p.x) + " Y: " + String(p.y));
    //Scale from 0->1023 to tft.width
    p.x = map(p.x, 0, TS_MAXY, tft.height(),0);
    p.y = map(p.y, 0, TS_MAXX, tft.width(),0);

    Serial.println("Mapped  X: " + String(p.x) + " Y: " + String(p.y));
    Serial.println("");

 
    if (screenStatus == 0)
      screenStatus = 1;

    else if (screenStatus == 1)
    {
      if (buttons[0].contains(p.x, p.y))
      {
        Serial.println("AUTO MODE");
        screenStatus = 2;
      }
      else if (buttons[1].contains(p.x, p.y))
      {
        Serial.println("MANUAL MODE");
        screenStatus = 3;
      }
    }
    else if (screenStatus == 2)
    {
      if (buttons[0].contains(p.x, p.y))
      {
        Serial.println("14 Pin Selected");
        screenStatus = 21;
        pinCount = 14;
      }
      else if (buttons[1].contains(p.x, p.y))
      {
        Serial.println("16 Pin Selected");
        screenStatus = 21;
        pinCount = 16;
      }
    }
    else if (screenStatus == 3)
    {
      if (buttons[0].contains(p.x, p.y))
      {
        Serial.println("Entering Keypad Mode");
        screenStatus = 30;
      }
    }
  }

  pinMode(XM, OUTPUT);
  digitalWrite(XM, LOW);
  pinMode(YP, OUTPUT);
  digitalWrite(YP, HIGH);

  if (screenStatus != lastStatus)
  {
    switch (screenStatus)
    {
      case 0: startScreen();
        break;
      case 1: modeScreen();
        break;
      case 2: autoScreen();
        break;
      case 21: autoSearch(pinCount);
        break;
      case 3: manualScreen();
        break;
      case 30: String number = getIC();
        manualSearch(number);
        break;
    }
    lastStatus = screenStatus;
  }
  delay(5);
}

void getTouch()
{
  boolean status = false;
  while (1)
  {
    digitalWrite(13, HIGH);
    TSPoint q = ts.getPoint();
    digitalWrite(13, LOW);
    pinMode(XM, OUTPUT);
    pinMode(YP, OUTPUT);

    if (q.z > MINPRESSURE && q.z < MAXPRESSURE)
    {
      status = true;
      break;
    }
    delay(10);
  }

  pinMode(XM, OUTPUT);
  digitalWrite(XM, LOW);
  pinMode(YP, OUTPUT);
  digitalWrite(YP, HIGH);
}

/*********************************************************** 
 * The section below was previously the file keypad.cpp    *
 ***********************************************************/
//UI details
#define BUTTON_X 34
#define BUTTON_Y 90
#define BUTTON_W 50
#define BUTTON_H 46
#define BUTTON_SPACING_X 13
#define BUTTON_SPACING_Y 13
#define BUTTON_TEXTSIZE 2

// text box where numbers go
#define TEXT_X 2
#define TEXT_Y 2
#define TEXT_W 317
#define TEXT_H 55
#define TEXT_TSIZE 4
#define TEXT_TCOLOR GREEN
#define TEXT_LEN 7

char buttonlabels[10][5] = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};


String getIC()
{ TSPoint ptemp;
  String number;
  int i = 0;
  boolean status = false;
  tft.fillScreen(BLACK);
  // create buttons
  for (uint8_t row = 0; row < 2; row++) {
    for (uint8_t col = 0; col < 5; col++) {
      buttons[col + row * 5].initButton(&tft, BUTTON_X + col * (BUTTON_W + BUTTON_SPACING_X),
                                        BUTTON_Y + row * (BUTTON_H + BUTTON_SPACING_Y), // x, y, w, h, outline, fill, text
                                        BUTTON_W, BUTTON_H, WHITE, BLACK, WHITE,
                                        buttonlabels[col + row * 5], BUTTON_TEXTSIZE);
      buttons[col + row * 5].drawButton();
    }
  }
  buttons[10].initButton(&tft, 90, BUTTON_Y + 2 * (BUTTON_H + BUTTON_SPACING_Y), 140, BUTTON_H, WHITE, GREEN, WHITE, "OK", BUTTON_TEXTSIZE
  );
  buttons[10].drawButton();

  buttons[11].initButton(&tft, 238, BUTTON_Y + 2 * (BUTTON_H + BUTTON_SPACING_Y), 140, BUTTON_H, WHITE, RED, WHITE, "Clear", BUTTON_TEXTSIZE);
  buttons[11].drawButton();
  // create 'text field'
  tft.drawRect(TEXT_X, TEXT_Y, TEXT_W, TEXT_H, WHITE);


  while (!status)
  {
    digitalWrite(13, HIGH);
    TSPoint p = ts.getPoint();
    digitalWrite(13, LOW);

    pinMode(XM, OUTPUT);
    pinMode(YP, OUTPUT);

    if (p.z > MINPRESSURE && p.z < MAXPRESSURE)
    {

        // scale from 0->1023 to tft.width
      p.x = map(p.x, TS_MINX, TS_MAXX, tft.height(), 0);
      p.y = map(p.y, TS_MINY, TS_MAXY, 0, tft.width());

      //Swapping for Set Rotation 
      p.x = p.x + p.y;
      p.y = p.x - p.y;
      p.x = 320 -( p.x - p.y) ; 
      Serial.println("Before X: " + String(p.x) + " Y: " + String(p.y));
    
    }

    // go thru all the buttons, checking if they were pressed
    for (uint8_t b = 0; b < 12; b++)
    {
      if (buttons[b].contains(p.x - 8, p.y - 8))
      {
        //Serial.print("Pressing: "); Serial.println(b);
        buttons[b].press(true);  // tell the button it is pressed
      }
      else
      {
        buttons[b].press(false);  // tell the button it is NOT pressed
      }
    }

    // now we can ask the buttons if their state has changed
    for (uint8_t b = 0; b < 12; b++)
    {
      if (buttons[b].justReleased())
      {
        //Serial.print("Released: "); Serial.println(b);
        buttons[b].drawButton();  // draw normal
      }

      if (buttons[b].justPressed())
      {
        buttons[b].drawButton(true);  // draw invert!

        // if a numberpad button, append the relevant # to the textfield
        if (b < 10) {
          if (i < TEXT_LEN)
          {
            number += buttonlabels[b][0];
            i++;
          }
        }

        // clr button! delete char
        if (b == 11) {
          tft.setCursor(TEXT_X + 2, TEXT_Y + 10);
          tft.setTextColor(BLACK);
          tft.setTextSize(TEXT_TSIZE);
          tft.print(number);
          number = "";
          i = 0;
        }

        // update the current text field
        //Serial.println(textfield);
        tft.setCursor(TEXT_X + 2, TEXT_Y + 10);
        tft.setTextColor(TEXT_TCOLOR, BLACK);
        tft.setTextSize(TEXT_TSIZE);
        tft.print(number);

        // we dont really check that the text field makes sense
        // just try to call
        if (b == 10) {
          Serial.print("IC no: "); Serial.println(number);
          status = true;
        }
        delay(100); // UI debouncing
      }
    }
  }
  return number;
}

/*********************************************************** 
 * sd_card.cpp                                             *
 ***********************************************************/


void SD_init()
{
  pinMode(SS, OUTPUT);

  if (!SD.begin(10, 11, 12, 13)) {
    Serial.println("Card failed, or not present");
    return;
  }
  Serial.println("SD card initialized.");
}

void autoSearch(int pins)
{
  tft.fillScreen(BLACK);

  tft.setCursor(25, 20);
  tft.setTextColor(GREEN);  tft.setTextSize(5);
  tft.println("IC TESTER");

  tft.setCursor(60, 65);
  tft.setTextColor(YELLOW);  tft.setTextSize(3);
  tft.println("Auto Search");
 Serial.println("Opening Datafile");
  File dataFile = SD.open(fname);
 Serial.println("Datafile open");
  String newCase;
  IC newIC;
  int ICpins;
  boolean result;
  IC ans[10];

  if (dataFile)
  {
    int count = 0;
    pin = new int[pins];

    if (pins == 16)
      pin = pin16;
    else if (pins == 14)
      pin = pin14;

    if( dataFile.available()) searching(1);
    while (dataFile.available())
    {
      
      dataFile.readStringUntil('$');

      newIC.num = dataFile.readStringUntil('\n');
      newIC.name = dataFile.readStringUntil('\n');
      ICpins = dataFile.readStringUntil('\n').toInt();
      Serial.println(newIC.num);
      testingIC(newIC.num);
      if (ICpins == pins)
      {
        result = true;

        Serial.println("Testing Now");

        while (dataFile.peek() != '$')
        {
          newCase = dataFile.readStringUntil('\n');
          newCase.trim();
          if (testCase(newCase, ICpins) == false)
          {
            result = false;
            break;
          }
        }

        if (result == true)
        {
          Serial.println("\nMatch Found !!\n");
          ans[count++] = newIC;
          //Serial.println(ans[count-1].num+"::"+ans[count-1].name);
        }

        Serial.println("Test Completed");
      }
      //searching(3);
    }
    delete(pin);
    dataFile.close();

    if (count == 0)
    {
      Serial.println("No Match Found");
      autoSearchResult(0);
    }
    else
    {
      Serial.println("\nCount : " + String(count));
      
      /*for (int i = 0; i < count; i++)
      {
        Serial.println(String(i) + ". " + ans[i].num + " : " + ans[i].name);
      }*/

      while (count--)
      {
        Serial.println(String(count) + ". " + ans[count].num + " : " + ans[count].name);
        autoSearchResult(1, ans[count].num, ans[count].name, count);
      }
    }
  }

  else
  {
    Serial.print("error opening "); Serial.println(fname);
    dataFile.close();
    SD.begin(10, 11, 12, 13);

    tft.setCursor(5, 140);
    tft.setTextColor(RED);  tft.setTextSize(4);
    tft.print("ERROR:");
    tft.setTextColor(MAGENTA);
    tft.println("SD CARD");

    tft.setCursor(40, 220);
    tft.setTextColor(RED);  tft.setTextSize(2);
    tft.println("Touch for MAIN MENU");

    getTouch();
    resetFunc();
  }
}

void manualSearch(String number)
{
  tft.fillScreen(BLACK);

  tft.setCursor(25, 1);
  tft.setTextColor(GREEN);  tft.setTextSize(5);          
  tft.println("IC TESTER");

  tft.setCursor(45, 55);
  tft.setTextColor(YELLOW);  tft.setTextSize(3);
  tft.println("Manual Search");

  // open the file. note that only one file can be open at a time,
  // so you have to close this one before opening another.
  File dataFile = SD.open(fname);

  String buffer;
  String newCase;
  IC newIC;
  int pins, send_status = -1;
  boolean result = true;

  // if the file is available, write to it:
  if (dataFile)
  {
    while (dataFile.available())
    {
      searching(1);
      result = true;
      dataFile.readStringUntil('$');

      buffer = dataFile.readStringUntil('\n');
      buffer.trim();

      Serial.println(buffer);

      if (number == buffer)
      {
        searching(2);
        newIC.num = buffer;
        newIC.name = dataFile.readStringUntil('\n');
        pins = dataFile.readStringUntil('\n').toInt();
        pin = new int[pins];

        if (pins == 16)
          pin = pin16;
        else if (pins == 14)
          pin = pin14;

        while (dataFile.peek() != '$')
        {
          newCase = dataFile.readStringUntil('\n');
          newCase.trim();
          if (testCase(newCase, pins) == false)
          {
            result = false;
          }
          delay(50);
          searching(3);
        }

        delete(pin);

        if (result == true)
        {
          Serial.println("IC is GOOD");
          send_status = 1;
        }
        else
        {
          Serial.println("IC is BAD");
          send_status = 0;
        }
        break;
      }
    }
    dataFile.close();
    if (send_status == -1)
      manualSearchResult(number, "", -1);
    else
      manualSearchResult(newIC.num, newIC.name, send_status);
  }
  else
  {
    Serial.print("error opening "); Serial.println(fname);
    dataFile.close();
    SD.begin(10, 11, 12, 13);

    tft.setCursor(5, 140);
    tft.setTextColor(RED);  tft.setTextSize(4);
    tft.print("ERROR:");
    tft.setTextColor(MAGENTA);
    tft.println("SD CARD");

    tft.setCursor(40, 220);
    tft.setTextColor(RED);  tft.setTextSize(2);
    tft.println("Touch for MAIN MENU");

    getTouch();
    resetFunc();
  }
}



/******************************************************************* 
 * The section below was previously the file test_functions.cpp    *
 *******************************************************************/


boolean testCase(String test, int pins)
{
  boolean result = true;
  int clkPin = -1;

  Serial.println("SignalIn : " + test);
  Serial.print("Response : ");

  //Setting Vcc, GND and INPUTS
  for (int i = 0; i < pins; i++)
  {
    switch (test[i])
    {
      case 'V' : pinMode(pin[i], OUTPUT); digitalWrite(pin[i], HIGH);
        break;
      case 'G' : pinMode(pin[i], OUTPUT); digitalWrite(pin[i], LOW);
        break;
      case 'L' : digitalWrite(pin[i], LOW); pinMode(pin[i], INPUT_PULLUP);
        break;
      case 'H' : digitalWrite(pin[i], LOW); pinMode(pin[i], INPUT_PULLUP);
        break;
    }
  }

  delay(5);

  //Setting Input Signals
  for (int i = 0; i < pins; i++)
  {
    switch (test[i])
    {
      case 'X' :
      case '0' : pinMode(pin[i], OUTPUT); digitalWrite(pin[i], LOW);
        break;
      case '1' : pinMode(pin[i], OUTPUT); digitalWrite(pin[i], HIGH);
        break;
      case 'C' : clkPin = pin[i]; pinMode(pin[i], OUTPUT); digitalWrite(pin[i], LOW);
        break;
    }
  }

  if (clkPin != -1)
  {
    //Clock Trigger
    pinMode(clkPin, INPUT_PULLUP);
    delay(10);
    pinMode(clkPin, OUTPUT);
    digitalWrite(clkPin, LOW);
  }

  delay(5);

  //Reading Outputs
  for (int i = 0; i < pins; i++)
  {
    switch (test[i])
    {
      case 'H' : if (!digitalRead(pin[i])) {
          result = false;
          Serial.print('L');
        }
        else Serial.print(' ');
        break;
      case 'L' : if (digitalRead(pin[i])) {
          result = false;
          Serial.print('H');
        }
        else Serial.print(' ');
        break;
      default : Serial.print(' ');
    }
  }
  Serial.println(";");
  //Serial.println("\nCase Result : "+String(result));
  return result;
}


/******************************************************************* 
 * The section below was previously the file tft.cpp               *
 *******************************************************************/


void tft_init()
{
  tft.reset();
  uint16_t identifier = tft.readID();
  if (identifier == 0x0101)
    identifier = 0x9341;
  tft.begin(identifier);
  Serial.println("TFT initialized!!");
  uint16_t ID = tft.readID(); //
   Serial.print("ID = 0x");
    Serial.println(ID, HEX);
  tft.setRotation(1);
  screenStatus = 0;
  startScreen();
}

void printText(int curX, int curY, int textSize, String text)
{
  tft.fillScreen(BLACK);
  tft.setCursor(curX, curY);
  tft.setTextColor(RED);
  tft.setTextSize(textSize);
  tft.println(text);
}

void startScreen()
{ 
  tft.fillScreen(BLACK);
  tft.setCursor(50, 40);
  tft.setTextColor(GREEN);  tft.setTextSize(4);
  tft.println("IC TESTER");
  tft.setCursor(150, 130);
  tft.setTextColor(WHITE); 
  tft.setCursor(50, 130);
  tft.setTextColor(WHITE);  tft.setTextSize(2);
  tft.println("Your name");
  tft.setCursor(25, 220);
  tft.setTextColor(RED);  tft.setTextSize(2);
  tft.println("Touch anywhere to START");

  leds[0] = CRGB(255,0,255); leds[1] = CRGB(255,0,255);
  FastLED.show();
  
}

void modeScreen()
{
  tft.fillScreen(BLACK);

  tft.setCursor(50, 20);
  tft.setTextColor(GREEN);  tft.setTextSize(4);
  tft.println("IC TESTER");

  tft.setCursor(50, 60);
  tft.setTextColor(WHITE);  tft.setTextSize(3);
  tft.println("Select Mode");

  buttons[0].initButton(&tft, 150, 120, 200, 40, BLACK, BLUE, WHITE, "Auto", 3);
  buttons[0].drawButton();

  buttons[1].initButton(&tft, 150, 180, 200, 40, BLACK, YELLOW, BLACK, "Manual", 3);
  buttons[1].drawButton();

  leds[0] = CRGB(255, 0, 255); leds[1] = CRGB(255, 0, 255);
  FastLED.show();
}

void autoScreen()
{
  tft.fillScreen(BLACK);

  tft.setCursor(6, 1);
  tft.setTextColor(GREEN);  tft.setTextSize(4);
  tft.println("IC TESTER");

  tft.setCursor(20, 60);
  tft.setTextColor(YELLOW);  tft.setTextSize(3);
  tft.println("Auto Search Mode");

  tft.setCursor(30, 120);
  tft.setTextColor(WHITE);  tft.setTextSize(2);
  tft.println("Select Number of Pins");

  buttons[0].initButton(&tft, 70, 180, 140, 40, WHITE, CYAN, BLACK, "14 Pins", 3);
  buttons[0].drawButton();

  buttons[1].initButton(&tft, 250, 180, 140, 40, WHITE, YELLOW, BLACK, "16 Pins", 3);
  buttons[1].drawButton();

  leds[0] = CRGB(0, 0, 255); leds[1] = CRGB(0, 0, 255);
  FastLED.show();
}

void autoSearchResult(int mode, String number = "", String name = "", int count = 0)
//void autoSearchResult(int mode, String number, String name, int count)
{
  tft.fillScreen(BLACK);

  tft.setCursor(25, 1);
  tft.setTextColor(GREEN);  tft.setTextSize(5);
  tft.println("IC TESTER");

  tft.setCursor(60, 55);
  tft.setTextColor(YELLOW);  tft.setTextSize(3);
  tft.println("Auto Search");

  tft.setTextColor(YELLOW);
  tft.setCursor(90, 80);
  tft.println("Complete");
  //*************************************************************
  if (mode != 0)
  {
    number = "IC-" + number;

    tft.setTextColor(CYAN); tft.setTextSize(3);
    tft.setCursor(0, 130);
    tft.println(number);

    tft.setTextColor(WHITE); tft.setTextSize(2);
    tft.println(name);
    tft.println();

    leds[0] = CRGB(0, 255, 0); leds[1] = CRGB(0, 255, 0);
    FastLED.show();
  }
  else
  {
    for (int i = 0; i < 3; i++)
    {
      tft.setCursor(40, 140);
      tft.setTextColor(BLACK);  tft.setTextSize(3);
      tft.print("NO MATCH FOUND");
      delay(500);
      tft.setCursor(40, 140);
      tft.setTextColor(RED);  tft.setTextSize(3);
      tft.print("NO MATCH FOUND");
      delay(500);

      leds[0] = CRGB(255, 0, 0); leds[1] = CRGB(255, 0, 0);
      FastLED.show();
    }
  }
  //*************************************************************
  tft.setCursor(40, 220);
  tft.setTextColor(RED);  tft.setTextSize(2);
  if (mode == 0 || count == 0)
  {
    tft.println("Touch for MAIN MENU");
    getTouch();
    resetFunc();
  }
  else
  {
    tft.println("Touch to CONTINUE");
    getTouch();
  }
}

void testingIC(String s)
{   tft.fillRect(75, 179, 102, 25, BLACK);
    tft.setCursor(80, 180);
    tft.println(s);
    //delay(2000);
}

void searching(int i)
{
  if (i == 1)
  {
    tft.setTextColor(BLACK);
    tft.setCursor(70, 150);
    tft.println("Testing...");
    tft.setTextColor(MAGENTA);
    tft.setCursor(70, 150);
    tft.println("Testing.");

    leds[0] = CRGB(255, 0, 255); leds[1] = CRGB(255, 0, 255);
    FastLED.show();
  }
  else if (i == 2)
  {
    tft.setTextColor(MAGENTA);
    tft.setCursor(70, 150);
    tft.println("Testing..");

    leds[0] = CRGB(0, 0, 0); leds[1] = CRGB(0, 0, 0);
    FastLED.show();
  }
  else if (i == 3)
  {
    tft.setTextColor(MAGENTA);
    tft.setCursor(70, 150);
    tft.println("Testing...");

    leds[0] = CRGB(255, 0, 255); leds[1] = CRGB(255, 0, 255);
    FastLED.show();
  }
  else if (i == -1)
  {
    tft.setTextColor(BLACK);
    tft.setCursor(70, 150);
    tft.println("Testing...");

    leds[0] = CRGB(0, 0, 0); leds[1] = CRGB(0, 0, 0);
    FastLED.show();
  }

}

void manualScreen()
{
  tft.fillScreen(BLACK);

  tft.setCursor(25, 1);
  tft.setTextColor(GREEN);  tft.setTextSize(5);
  tft.println("IC TESTER");

  tft.setCursor(45, 60);
  tft.setTextColor(YELLOW);  tft.setTextSize(3);
  tft.println("Manual Search");
  tft.setCursor(125, 85);
  tft.println("Mode");

  tft.setCursor(60, 135);
  tft.setTextColor(WHITE);  tft.setTextSize(2);
  tft.println("Enter IC Number:");

  buttons[0].initButton(&tft, 160, 190, 200, 50, BLACK, BLUE, WHITE, "ENTER >", 4);
  buttons[0].drawButton();

  leds[0] = CRGB(255, 255, 0); leds[1] = CRGB(255, 255, 0);
  FastLED.show();
}

void manualSearchResult(String number, String name, int status)
{

  tft.fillScreen(BLACK);
  tft.setCursor(25, 1);
  tft.setTextColor(GREEN);  tft.setTextSize(5);
  tft.println("IC TESTER");

  tft.setCursor(45, 55);
  tft.setTextColor(YELLOW);  tft.setTextSize(3);
  tft.println("Manual Search");

  tft.setTextColor(YELLOW);
  tft.setCursor(90, 80);
  tft.println("Complete");

  number = "IC-" + number;

  tft.setTextColor(CYAN); tft.setTextSize(3);
  tft.setCursor(0, 130);
  tft.println(number);

  if (status != -1)
  {
    tft.setTextColor(WHITE); tft.setTextSize(2);
    tft.println(name);
    tft.println();
  }
  for (int i = 0; i < 2; i++)
  {
    delay(500);
    tft.setCursor(0, 130);
    tft.setTextColor(BLACK); tft.setTextSize(3);
    tft.setCursor(0, 130);
    tft.println(number);
    delay(400);
    switch (status)
    {
      case 0 : tft.setTextColor(RED); tft.setTextSize(3);
        leds[0] = CRGB(255, 0, 0); leds[1] = CRGB(255, 0, 0);
        FastLED.show();
        break;
      case 1 : tft.setTextColor(GREEN); tft.setTextSize(3);
        leds[0] = CRGB(0, 255, 0); leds[1] = CRGB(0, 255, 0);
        FastLED.show();
        break;
      case -1 : tft.setTextColor(MAGENTA); tft.setTextSize(3);
        leds[0] = CRGB(255, 0, 255); leds[1] = CRGB(255, 0, 255);
        FastLED.show();
        break;
    }
    tft.setCursor(0, 130);
    tft.println(number);
  }

  if (status == -1)
  {
    tft.setTextColor(RED);
    tft.println("IC NOT FOUND");
    leds[0] = CRGB(0, 0, 0); leds[1] = CRGB(0, 0, 0);
    FastLED.show();
  }

  tft.setCursor(40, 220);
  tft.setTextColor(RED);  tft.setTextSize(2);
  tft.println("Touch for MAIN MENU");

  getTouch();
  resetFunc();
}

